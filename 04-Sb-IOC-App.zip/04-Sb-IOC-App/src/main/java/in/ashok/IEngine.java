package in.ashok;

public interface IEngine 
{
	public boolean start();
}
