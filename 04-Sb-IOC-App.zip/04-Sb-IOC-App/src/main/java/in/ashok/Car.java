package in.ashok;

public class Car {
	
	
	
	public Car()
	{
		System.out.println("Car() :: class constructor");
	}
	
	
	private IEngine engine;
	public void drive()
	{
		boolean status = engine.start();
		
		if(status)
		{
			System.out.println("journey started....");
		}
		else
		{
			System.out.println("engine failed to start...");
		}
	}

}
